const Livro = require('../models/Livro');
function index(req, res) { res.json(Livro.listarTodos()); }
function show(req, res) {
const livro = Livro.buscarPorId(req.params.id);
if (!livro) { return res.status(404).json({ erro: 'Livro não encontrado' }); }
res.json(livro);
}
function store(req, res) {
const { titulo, autor, categoria } = req.body;
if (!titulo || !autor) { return res.status(400).json({ erro: 'Título e autor são obrigatórios' }); }
const novoLivro = Livro.criar({ titulo, autor, categoria });
res.status(201).json(novoLivro);
}
function update(req, res) {
const livroAtualizado = Livro.atualizar(req.params.id, req.body);
if (!livroAtualizado) { return res.status(404).json({ erro: 'Livro não encontrado' }); }
res.json(livroAtualizado);
}
function destroy(req, res) {
const removido = Livro.remover(req.params.id);
if (!removido) { return res.status(404).json({ erro: 'Livro não encontrado' }); }
res.status(204).send();
}
module.exports = { index, show, store, update, destroy };