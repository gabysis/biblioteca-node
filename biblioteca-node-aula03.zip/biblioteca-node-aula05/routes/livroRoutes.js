const express = require('express');
const router = express.Router();
const livroController = require('../controllers/livroController');
router.get('/', livroController.index);
router.get('/:id', livroController.show);
router.post('/', livroController.store);
router.put('/:id', livroController.update);
router.delete('/:id', livroController.destroy);
module.exports = router;
