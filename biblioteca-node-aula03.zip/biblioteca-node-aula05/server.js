const express = require('express');
const app = express();
const PORTA = 3000;
app.use(express.json()); // middleware que interpreta JSON no corpo das requisições
const livroRoutes = require('./routes/livroRoutes');
app.use('/livros', livroRoutes);
app.listen(PORTA, () => {
 console.log(`Servidor rodando em http://localhost:${PORTA}`);
});
