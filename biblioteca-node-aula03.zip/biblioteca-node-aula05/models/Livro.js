// Nosso "banco de dados" temporário, em memória
let livros = [
{ id: 1, titulo: 'Dom Casmurro', autor: 'Machado de Assis', categoria: 'Romance' },
{ id: 2, titulo: 'O Cortiço', autor: 'Aluísio Azevedo', categoria: 'Romance' },
];
let proximoId = 3;
function listarTodos() { return livros; }
function buscarPorId(id) { return livros.find((livro) => livro.id === Number(id)); }
function criar(dados) {
const novoLivro = { id: proximoId++, ...dados };
livros.push(novoLivro);
return novoLivro;
}
function atualizar(id, dados) {
const livro = buscarPorId(id);
if (!livro) return null;
Object.assign(livro, dados);
return livro;
}
function remover(id) {
const existe = buscarPorId(id);
if (!existe) return false;
livros = livros.filter((livro) => livro.id !== Number(id));
return true;
}
module.exports = { listarTodos, buscarPorId, criar, atualizar, remover };