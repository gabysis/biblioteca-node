const express = require('express');
const app = express();
const sequelize = require('./config/sequelize');
app.use(express.json());
sequelize.sync()
 .then(() => console.log('Tabelas sincronizadas com sucesso!'))
 .catch((erro) => console.error('Erro ao sincronizar:', erro));
const livroRoutes = require('./routes/livroRoutes');
app.use('/livros', livroRoutes);
app.listen(3000, () => console.log('Servidor rodando na porta 3000'));
