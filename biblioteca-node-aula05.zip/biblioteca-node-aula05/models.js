const { DataTypes } = require('sequelize');
const sequelize = require('../config/sequelize');
const Livro = sequelize.define('Livro', {
titulo: { type: DataTypes.STRING, allowNull: false },
autor: { type: DataTypes.STRING, allowNull: false },
categoria: { type: DataTypes.STRING },
disponivel: { type: DataTypes.BOOLEAN, defaultValue: true },
}, {
tableName: 'livros',
timestamps: true, // cria createdAt e updatedAt automaticamente
});
module.exports = Livro