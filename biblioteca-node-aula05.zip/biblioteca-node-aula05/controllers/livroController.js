const Livro = require('../models/Livro');
async function index(req, res) {
 const livros = await Livro.findAll();
 res.json(livros);
}
async function show(req, res) {
 const livro = await Livro.findByPk(req.params.id);
 if (!livro) return res.status(404).json({ erro: 'Livro não encontrado' });
 res.json(livro);
}
async function store(req, res) {
 const novoLivro = await Livro.create(req.body);
 res.status(201).json(novoLivro);
}
async function update(req, res) {
 const livro = await Livro.findByPk(req.params.id);
 if (!livro) return res.status(404).json({ erro: 'Livro não encontrado' });
 await livro.update(req.body);
 res.json(livro);
}
async function destroy(req, res) {
 const livro = await Livro.findByPk(req.params.id);
 if (!livro) return res.status(404).json({ erro: 'Livro não encontrado' });
 await livro.destroy();
 res.status(204).send();
}
module.exports = { index, show, store, update, destroy };