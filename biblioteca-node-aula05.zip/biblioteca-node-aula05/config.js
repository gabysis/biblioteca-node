const { Sequelize } = require('sequelize');
const sequelize = new Sequelize('biblioteca', 'root', 'SUA_SENHA_AQUI', {
 host: 'localhost',
 dialect: 'mysql',
 logging: false, // desliga o log de todas as queries geradas no console
});
module.exports = sequelize